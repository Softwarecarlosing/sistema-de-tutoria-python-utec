'/logs', 'application.controllers.logs.index.Index',
'/logs/printer', 'application.controllers.logs.printer.Printer',
'/logs/view/(.+)', 'application.controllers.logs.view.View',