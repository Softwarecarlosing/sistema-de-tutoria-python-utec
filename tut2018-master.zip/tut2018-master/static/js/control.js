$(document).ready(function() {
    $('#datos_tabla').DataTable();
});